const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('game')
    .setDescription('Play Tic-Tac-Toe vs the computer!'),

  async execute(interaction) {
    const emptyBoard = [
      [' ', ' ', ' '],
      [' ', ' ', ' '],
      [' ', ' ', ' ']
    ];

    const makeButton = (label, id) =>
      new ButtonBuilder()
        .setCustomId(id)
        .setLabel(label === ' ' ? '⬜' : label)
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(label !== ' ');

    const renderBoard = (board) => {
      return [
        new ActionRowBuilder().addComponents(board[0].map((v, i) => makeButton(v, `0-${i}`))),
        new ActionRowBuilder().addComponents(board[1].map((v, i) => makeButton(v, `1-${i}`))),
        new ActionRowBuilder().addComponents(board[2].map((v, i) => makeButton(v, `2-${i}`))),
      ];
    };

    const checkWinner = (b, p) => {
      return (
        [0, 1, 2].some(i => b[i].every(cell => cell === p)) || // row
        [0, 1, 2].some(i => b.every(row => row[i] === p)) ||   // column
        (b[0][0] === p && b[1][1] === p && b[2][2] === p) ||   // diag
        (b[0][2] === p && b[1][1] === p && b[2][0] === p)      // anti-diag
      );
    };

    await interaction.reply({ content: 'Your turn! You are ❌', components: renderBoard(emptyBoard) });

    const msg = await interaction.fetchReply();
    const collector = msg.createMessageComponentCollector({ time: 60000 });

    collector.on('collect', async btn => {
      if (btn.user.id !== interaction.user.id) {
        await btn.reply({ content: 'This is not your game!', ephemeral: true });
        return;
      }

      const [row, col] = btn.customId.split('-').map(Number);

      if (emptyBoard[row][col] !== ' ') {
        await btn.reply({ content: 'That spot is taken!', ephemeral: true });
        return;
      }

      emptyBoard[row][col] = '❌';

      if (checkWinner(emptyBoard, '❌')) {
        collector.stop();
        await btn.update({ content: '🎉 You win!', components: renderBoard(emptyBoard) });
        return;
      }

      // Computer move
      const emptyCells = [];
      for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
          if (emptyBoard[i][j] === ' ') emptyCells.push([i, j]);
        }
      }

      if (emptyCells.length === 0) {
        collector.stop();
        await btn.update({ content: 'It\'s a draw!', components: renderBoard(emptyBoard) });
        return;
      }

      const [r, c] = emptyCells[Math.floor(Math.random() * emptyCells.length)];
      emptyBoard[r][c] = '⭕';

      if (checkWinner(emptyBoard, '⭕')) {
        collector.stop();
        await btn.update({ content: '💀 You lost!', components: renderBoard(emptyBoard) });
        return;
      }

      await btn.update({ components: renderBoard(emptyBoard) });
    });

    collector.on('end', async () => {
      await interaction.editReply({ content: '⏰ Game over! (Timeout)', components: renderBoard(emptyBoard).map(row => {
        row.components.forEach(btn => btn.setDisabled(true));
        return row;
      }) });
    });
  },
};
