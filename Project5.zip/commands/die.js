const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('die')
        .setDescription('Kills the bot'),
    async execute(interaction, client) {
        await interaction.reply('💀 Shutting down...');
        setTimeout(() => process.exit(), 1000);
    },
};
