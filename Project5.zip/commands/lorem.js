const { SlashCommandBuilder } = require('discord.js');
const lorem = require('../lorem');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('lorem')
        .setDescription('Displays lorem ipsum text'),
    async execute(interaction) {
        await interaction.reply(lorem);
    },
};
