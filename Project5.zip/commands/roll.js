const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('roll')
        .setDescription('Roll a die')
        .addStringOption(option =>
            option.setName('size')
                .setDescription('Choose a die size')
                .setRequired(true)
                .addChoices(
                    { name: 'd4', value: '4' },
                    { name: 'd6', value: '6' },
                    { name: 'd10', value: '10' },
                    { name: 'd20', value: '20' },
                )),
    async execute(interaction) {
        const size = parseInt(interaction.options.getString('size'));
        const roll = Math.floor(Math.random() * size) + 1;
        await interaction.reply(`🎲 You rolled a **${roll}** on a d${size}!`);
    },
};
