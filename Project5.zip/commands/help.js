const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Displays the available commands'),
    async execute(interaction) {
        await interaction.reply({
            content: '**Available Commands:**\n/help\n/lorem\n/die\n/roll\n/game',
            ephemeral: true
        });
    },
};
